#ifndef _CONFIG_H_
#define _CONFIG_H_

#define CODEMEM
#define LINE_PARSE
//#define DEBUG_ENABLE

#endif
